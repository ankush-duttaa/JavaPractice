import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/*check the particualr value in an Array */
public class Valuecheck{
	
	public static void main(String [] args) { 
		int arr[] = {1,4,10,15,3,2,7};

		
	for(int i=0; i<arr.length; i++)
	{
	
			list.splice( list.indexOf((15), 1 );
			
		}
	
		
	System.out.println("After Remove new Array is  : " +Arrays.toString(arr));
	}
}


	
	
	
	
 